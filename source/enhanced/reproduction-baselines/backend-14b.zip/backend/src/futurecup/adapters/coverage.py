"""Bounded lexical retrieval and conservative rule-reflection checks (no model calls).

COVERED means a strongly matching normative sentence was injected, never semantic
completeness. Only one key rule per topic is selected; arbitrary inference is not
verified. Required topics may be supplied by the caller, not by source documents.
"""
from __future__ import annotations

import re
from decimal import Decimal
import time
from collections.abc import Callable, Sequence
from typing import Any

from futurecup.domain.errors import RuntimeFault

Hit = dict[str, Any]
Search = Callable[[Sequence[str], str, int], list[Hit]]
Tokenizer = Callable[[str], list[str]]
RULE = re.compile(r"\b(?:must|shall|required|prohibited)\b|\u5fc5\u987b|\u4e0d\u5f97|\u7981\u6b62|\u5e94\u5f53", re.I)
QUANTITY = re.compile(r"(\d+(?:\.\d+)?)\s*(minutes?|hours?|days?|\u5206\u949f|\u5c0f\u65f6|\u5929)", re.I)


def identify(query: str, *, limit: int = 8) -> list[dict]:
    """Language-independent clause extraction, not LLM topic understanding.

    Explicit topics are recommended for compound clauses without separators.
    Long unseparated clauses become bounded windows instead of silently truncating.
    """
    pieces = re.split(r"[\n,;\u3001\uff0c\uff1b\u3002]+|\b(?:and|also)\b|\u4ee5\u53ca|\u5e76\u4e14|\u540c\u65f6", query, flags=re.I)
    values: list[str] = []
    for piece in pieces:
        piece = piece.strip()
        for start in range(0, len(piece), 140):
            text = piece[start:start+160]
            if len(text) >= 2 and text not in values:
                values.append(text)
    return [{"id": f"topic-{i+1}", "query": text, "required": False}
            for i, text in enumerate(values[:limit])]


def validate_topics(topics: object) -> list[dict]:
    if not isinstance(topics, list) or not 1 <= len(topics) <= 8:
        raise RuntimeFault("coverage_topics", "Provide 1..8 bounded topics", 422)
    seen = set()
    result = []
    for topic in topics:
        if (not isinstance(topic, dict) or set(topic)-{"id", "query", "required"}
            or not isinstance(topic.get("id"), str)
            or not re.fullmatch(r"[a-zA-Z0-9_-]{1,48}", topic["id"])
            or topic["id"] in seen or not isinstance(topic.get("query"), str)
            or not 2 <= len(topic["query"].strip()) <= 160
            or type(topic.get("required", False)) is not bool):
            raise RuntimeFault("coverage_topics", "Invalid or duplicate coverage topic", 422)
        seen.add(topic["id"])
        result.append({"id": topic["id"], "query": topic["query"].strip(), "required": topic.get("required", False)})
    return result


def retrieve_topics(search: Search, tokenize: Tokenizer, scope: Sequence[str], query: str,
                    topics: list[dict] | None = None, *, max_hits: int = 4,
                    max_queries: int = 16, max_chars: int = 6000,
                    timeout: float = .5) -> dict:
    explicit = topics is not None
    selected = validate_topics(topics if explicit else identify(query))
    if (type(max_hits) is not int or not 1 <= max_hits <= 8
        or type(max_queries) is not int or not 1 <= max_queries <= 16
        or type(max_chars) is not int or not 128 <= max_chars <= 16000
        or not 0 < timeout <= 2):
        raise RuntimeFault("coverage_limits", "Invalid coverage resource limits", 422)
    started = time.perf_counter()
    queries: list[dict] = []
    reports: list[dict] = []
    ranked: list[list[Hit]] = []

    def deadline() -> None:
        if time.perf_counter()-started >= timeout:
            raise RuntimeFault("coverage_timeout", "Retrieval deadline exceeded; not proof of absence", 408)

    def run(text: str, limit: int, topic: str, phase: str) -> list[Hit]:
        deadline()
        if len(queries) >= max_queries:
            return []
        try:
            hits = search(scope, text, limit)
        except RuntimeFault:
            raise
        except Exception:
            raise RuntimeFault("coverage_retrieval_error", "Retrieval failed; not proof of absence", 503) from None
        deadline()
        queries.append({"topic_id": topic, "query": text, "phase": phase,
                        "hit_ids": [hit["id"] for hit in hits]})
        return hits

    for topic in selected:
        before = len(queries)
        hits = run(topic["query"], 2, topic["id"], "initial")
        tokens = set(tokenize(topic["query"]))

        def classify(hit: Hit) -> tuple[float, list[str]]:
            overlap = len(tokens & set(tokenize(hit["text"]))) / max(1, len(tokens))
            sentences = [s.strip() for s in re.split(r"(?:\.(?!\d)|[\n!?\u3002\uff01\uff1f])", hit["text"]) if RULE.search(s)]
            rules = [s for s in sentences if len(s) <= 400 and
                     len(tokens & set(tokenize(s))) / max(1, len(tokens)) >= .35]
            return overlap, rules

        supplemented = not any(classify(h)[0] >= .75 and classify(h)[1] for h in hits)
        if supplemented:
            # Deeper top-K of the same topic recovers rules below initial top-2.
            extras = run(topic["query"], 8, topic["id"], "supplement")
            hits = list({h["id"]: h for h in hits+extras}.values())
        order = sorted(hits, key=lambda h: (-bool(classify(h)[1]), -classify(h)[0], h["score"], h["id"]))
        overlap, rules = classify(order[0]) if order else (0., [])
        strong = overlap >= .75 and bool(rules)
        queried = len(queries) > before
        reports.append({"id": topic["id"], "query": topic["query"],
            # Automatic topics enforce ONLY strongly relevant discovered rules.
            "required": topic["required"] if explicit else strong,
            "requirement_origin": "caller" if explicit else "lexical_discovery",
            "status": "COVERED" if strong else "PARTIAL" if order else "UNCOVERED",
            "search_state": "QUERIED" if queried else "QUERY_BUDGET_EXHAUSTED",
            "candidate_ids": [h["id"] for h in order],
            "critical_rule": rules[0] if strong else None,
            "rule_chunk_id": order[0]["id"] if strong else None})
        ranked.append(order)

    # Topic round robin prevents one broad topic exhausting all context slots.
    merged: list[Hit] = []
    seen = set()
    size = 0
    for depth in range(8):
        for hits in ranked:
            if depth >= len(hits):
                continue
            hit = hits[depth]
            if hit["id"] in seen or len(merged) >= max_hits or size+len(hit["text"]) > max_chars:
                continue
            merged.append(hit)
            seen.add(hit["id"])
            size += len(hit["text"])
    for topic in reports:
        topic["injected_ids"] = [i for i in topic["candidate_ids"] if i in seen]
        if topic["rule_chunk_id"] not in seen:
            topic["status"] = "PARTIAL" if topic["candidate_ids"] else "UNCOVERED"
        if not topic["injected_ids"] and topic["candidate_ids"]:
            topic["search_state"] = "CONTEXT_BUDGET_EXHAUSTED"
    deadline()
    return {"hits": merged, "coverage": reports, "queries": queries,
        "retrieval_calls": len(queries), "context_chars": size,
        "elapsed_ms": (time.perf_counter()-started)*1000,
        "topic_extraction_truncated": not explicit and len(identify(query, limit=9)) > 8,
        "coverage_definition": "lexical overlap >= .75 plus a normative sentence >= .35 overlap; evidence discovery, not semantic completeness",
        "coverage_version": "topics-v1"}


def compact_context(record: dict) -> dict:
    """Audit keeps full query history; model gets bounded evidence only once."""
    keys = ("id", "query", "required", "status", "critical_rule", "rule_chunk_id")
    return {"hits": record["hits"], "coverage": [{k: t[k] for k in keys}
        for t in record.get("coverage", [])], "context_sha256": record["context_sha256"]}


def assess_output(value: object, records: Sequence[dict]) -> list[dict]:
    """Exact key-rule reflection and narrow quantity contradiction detection.

    A conservative check may reject faithful paraphrases. It does NOT prove all
    statements correct, and unsupported free-form claims are not generally judged.
    """
    if not isinstance(value, dict):
        value = {}
    citations = value.get("citations", [])
    citations = citations if isinstance(citations, list) else []
    text = "\n".join([str(value.get("markdown", "")), str(value.get("summary", "")),
                      *map(str, value.get("items", []))])
    results = []
    for record in records:
        for topic in record.get("coverage", []):
            if not topic["required"]:
                continue
            rule, chunk = topic["critical_rule"], topic["rule_chunk_id"]
            if topic.get("search_state") != "QUERIED":
                state = "COVERAGE_RESOURCE_LIMIT"
            elif not topic["injected_ids"]:
                # Label must be on the same line as the missing topic.
                state = "SOURCE_UNAVAILABLE_ADVICE" if any(topic["query"] in line and
                    ("design suggestion" in line.lower() or "\u8bbe\u8ba1\u5efa\u8bae" in line)
                    for line in text.splitlines()) else "SOURCE_UNAVAILABLE_UNMARKED"
            elif not rule:
                state = "INSUFFICIENT_EVIDENCE"
            elif not any(isinstance(c, dict) and c.get("chunk_id") == chunk and
                         isinstance(c.get("quote"), str) and rule in c["quote"] for c in citations):
                state = "SOURCE_NOT_CITED"
            else:
                from futurecup.adapters.knowledge import terms
                query_tokens = set(terms(topic["query"]))
                units = {unit.lower().rstrip("s"): Decimal(number) for number, unit in QUANTITY.findall(rule)}
                conflict = any(len(query_tokens & set(terms(line))) / max(1, len(query_tokens)) >= .5
                    and any(unit.lower().rstrip("s") in units and units[unit.lower().rstrip("s")] != Decimal(number)
                            for number, unit in QUANTITY.findall(line)) for line in text.splitlines())
                state = "POSSIBLE_CONFLICT" if conflict else "RULE_REFLECTED" if rule in text else "SOURCE_NOT_REFLECTED"
            results.append({"topic_id": topic["id"], "status": state,
                "rule_chunk_id": chunk, "requirement_origin": topic.get("requirement_origin", "caller")})
    return results
