"""HTTP delivery layer."""
